package com.mycompany.inhertitance_concrete_class.model;

public class CD {

}
