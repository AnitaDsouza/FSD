package com.mycompany.inhertitance_hibernate;

import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.mycompany.inhertitance_hibernate.model.Developer;
import com.mycompany.inhertitance_hibernate.model.Employee;
import com.mycompany.inhertitance_hibernate.model.HumanResource;

public class Company {
	public static void main(String[] args) {
		try {
			
			SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Employee.class)
					.addAnnotatedClass(HumanResource.class)
					.addAnnotatedClass(Developer.class).buildSessionFactory();
			Session session = factory.openSession();
			Employee emp  = new Employee( "anita", "Rush", new Date(), 9.99);
			Developer demp = new Developer("java" , "anita", "Rush", new Date(), 9.99);
			HumanResource hremp = new HumanResource("Manager",5,"anita", "Rush", new Date(), 9.99);
			session.getTransaction().begin();
			session.save(emp);
			session.save(demp);
			session.save(hremp);
			session.getTransaction().commit();
			System.out.println("ok..");
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}