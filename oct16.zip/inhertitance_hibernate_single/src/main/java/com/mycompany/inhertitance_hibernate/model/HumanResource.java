package com.mycompany.inhertitance_hibernate.model;


import java.util.*;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

import lombok.Data;
import lombok.EqualsAndHashCode;
@Entity
@Data
@EqualsAndHashCode(callSuper = false)
@DiscriminatorValue("HR")

public class HumanResource extends Employee {
	private String position;
	private int recurit;

	public HumanResource() {
	}

	public HumanResource(String position, int recurit ,  String name, String department, Date date_of_joining, double salary) {
		super( name, department, date_of_joining, salary);
		this.position = position;
		this.recurit = recurit;
		
	}

	


}