package com.mycompany.inhertitance_hibernate.model;

import java.util.Date;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

import lombok.Data;
@Entity
@Data
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "employee_type")
@DiscriminatorValue("employee")
public class Employee {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String name;
	private String department;
	private Date date_of_joining;
	private double salary;

	public Employee() {
	}

	public Employee( String name, String department, Date date_of_joining, double salary) {
		super();
		
		this.name = name;
		this.department = department;
		this.date_of_joining = date_of_joining;
		this.salary = salary;
	}

	
}