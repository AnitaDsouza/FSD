package com.mycompany.inhertitance_hibernate.model;

import java.util.*;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Data
@EqualsAndHashCode(callSuper = false)
@DiscriminatorValue("Developer")
public class Developer extends Employee {
	
	private String domain;

	public Developer() {
		super();
	}

	public Developer(String domain, String name, String department, Date date_of_joining, double salary) {
		super( name, department, date_of_joining, salary);
		// TODO Auto-generated constructor stub
		this.domain = domain ;
	}
}