/*
 * package com.mycompany.one_to_one; import java.util.List; import
 * java.util.Scanner;
 * 
 * import org.hibernate.Session; import org.hibernate.SessionFactory; import
 * org.hibernate.cfg.Configuration;
 * 
 * 
 * 
 * public class App {
 * 
 * 
 * public static void main(String[] args) {
 * 
 * 
 * 
 * 
 * } }
 */